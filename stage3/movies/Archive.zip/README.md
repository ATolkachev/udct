# Quick Start

* Open Terminal
* Type python {full_enterntainment_center.py path}
* Enjoy the trailers. Learn Russian (a bit)!
